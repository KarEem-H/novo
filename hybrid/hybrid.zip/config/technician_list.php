<?php 

 $technicians = array(
        
	'Norman Jeweson Carasi',
	'Dechilito Abener Villariez',
	'Randy Enconado',
	'Jemark Irlanez',
	'Fernando Dela Cruz',
	'Jonathan Catalan',
	'Mark Lester Moneva',
	'Roderick Gacutan',
	'Ramon Faustino',
	'Jetlee Atienza',
	'Galdwin Vales',
	'Rener Gonzales',
	'Arnold Lopez',
	'Sherwin Pimentel',
	'Francisco Ignadio',
	'Cesario Aquino Dayao JR'

    );

 sort($technicians);


?>