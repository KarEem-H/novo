SELECT id as contactid, customer_name as firstname, customer_mobile as phonemobile FROM table_contacts WHERE customer_mobile like '%[Number]%'


SELECT id as contactid, customer as firstname, mobile as phonemobile FROM invoice WHERE mobile like '%[Number]%'


SELECT * FROM information_schema.user_privileges WHERE grantee LIKE "'u18czoba1wax'%"


config/site.php

94.200.40.26

SHOW GRANTS FOR 'jijo'@'94.200.40.26';

3CX connectivity with VPS
-------------------------
Server: 64.202.187.72
database: telesales
user name: jijo
pwd: Dubai@2020


